import React from 'react'
import Logo from '../imdb.png'
import {Link} from 'react-router-dom'

function Navigation() {
  return (
    <div className='flex border space-x-8 items-center pl-3 py-4'>
       <img className='w-[50px]' src={Logo} />
       <Link to="/" className='text-xl font-bold text-gray-800 uppercase'>Movies</Link>
       <Link to="/watchlist" className='text-xl font-bold text-gray-800 uppercase'>Watchlist</Link>
    </div>
  )
}

export default Navigation
