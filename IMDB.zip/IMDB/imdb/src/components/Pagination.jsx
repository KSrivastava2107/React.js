import React from 'react'

function Pagination({handlePrev,handleNext,pageNo}) {
  return (
    <div className='bg-gray-400 p-1 m-3 w-full rounded-full transform -translate-x-3 flex items-center justify-center min-v-screen gap-4'>
        <div onClick={handlePrev} className='p-1 z-10'><i class="fa-solid fa-backward"></i></div>
        <div className='font-bold'>{pageNo}</div>
      <div onClick={handleNext} className='p-1 z-10'><i class="fa-solid fa-forward"></i></div>
    </div>
  )
}

export default Pagination
