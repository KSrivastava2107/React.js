import React,{useRef} from 'react'

function Banner() {

  return (
    <div className='w-full h-[70vh] bg-cover bg-center relative' style={{backgroundImage:`url(https://wallpapercave.com/wp/wp5394632.jpg)`}}>
      <div className='absolute bottom-0 w-full text-white text-sm text-center p-3'>Avengers Endgame</div>
    </div>
  )
}

export default Banner
