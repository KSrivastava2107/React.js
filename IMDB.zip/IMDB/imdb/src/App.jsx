import './App.css'
import Navigation from './components/Navigation'
import WatchList from './components/WatchList'
import Movies from './components/Movies'
import Banner from './components/Banner'
import { useEffect, useState } from 'react'
import { BrowserRouter,Routes,Route, useSearchParams } from 'react-router-dom'

function App() {
  let [watchlist,setWatchList]=useState([])
  let handleAddtoWatchlist=(movieObj)=>{
    let newWatchList=[...watchlist,movieObj]
    localStorage.setItem('movieApp',JSON.stringify(newWatchList))
    setWatchList(newWatchList)
    console.log(newWatchList)
  }

  let handleRemoveFromWatchlist=(movieObj)=>{
        let filteredWatchList=watchlist.filter((movie)=>{
          return movie.id != movieObj.id
        });
          setWatchList(filteredWatchList)
          localStorage.setItem("movieApp",JSON.stringify(filteredWatchList))
  };

  useEffect(()=>{
    let moviesFromLocalStorage=localStorage.getItem('movieApp')
    if(!moviesFromLocalStorage){
      return
    }
    setWatchList(JSON.parse(moviesFromLocalStorage))
  },[]);

  return (
    <>
    <BrowserRouter>
     <Navigation/>
     <Routes>
     <Route path="/" element={<><Banner/><Movies watchlist={watchlist} handleAddtoWatchlist={handleAddtoWatchlist} handleRemoveFromWatchlist={handleRemoveFromWatchlist}/></>}/>
     <Route path="/watchlist" element={<WatchList watchlist={watchlist} setWatchList={setWatchList} setWatchLis={setWatchList} handleRemoveFromWatchlist={handleRemoveFromWatchlist}/>}/>
     </Routes>
     </BrowserRouter>
    </>
  )
}

export default App
