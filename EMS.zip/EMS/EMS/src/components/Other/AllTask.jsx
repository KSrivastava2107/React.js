{/*import React, { useContext } from 'react';
import { AuthContext } from '../../context/AuthProvider';

const AllTask = () => {
  
  const authData=useContext(AuthContext)
  

  return (
    <div className="flex justify-end items-center">
      <div className='bg-[#1C1C1C] rounded overflow-auto p-2 h-[20vh] w-[50vw] border-2 relative' id="tasklist">
        <h2 className='justify-center items-center px-2 py-1 text-center text-white font-semibold rounded-full mb-1 flex bg-transparent border-2'>Task Update</h2>
        {authData.employees.map(function(elem){
          return <div className='bg-gradient-to-r from-teal-500 to-blue-600 mb-2 py-2 px-2 flex justify-between rounded-full'>
         
        </div>
        })}
      </div>
    </div>
  );
}

export default AllTask;
*/}

{/*}
import React, { useContext } from 'react';
import { AuthContext } from '../../context/AuthProvider';

const AllTask = () => {
  
  const authData = useContext(AuthContext);

  return (
    <div className="flex justify-end items-center">
      <div className='bg-[#1C1C1C] rounded overflow-hidden p-2 h-[20vh] w-[50vw] border-2 relative' id="tasklist">
        <h2 className='justify-center items-center px-2 py-1 text-center text-white font-semibold rounded-full mb-1 flex bg-transparent border-2'>
          Task Update
        </h2>
        
        <div className='overflow-auto h-[16vh]' id='tasklist'>
          {authData.employees.map(function(elem){
            return (
              <div className='bg-gradient-to-r from-teal-500 to-blue-600 mb-2 py-2 px-2 flex justify-between rounded-full'>
                <h1>{elem.firstName}</h1>
                
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default AllTask;*/}


import React, { useContext } from 'react';
import { AuthContext } from '../../context/AuthProvider';

const AllTask = () => {
  
  const [userData,setUserData] = useContext(AuthContext);

  return (
    <div className="flex justify-end items-center">
      <div className='bg-[#1C1C1C] rounded overflow-hidden p-2 h-[20vh] w-[50vw] border-2 relative' id="tasklist">
        <h2 className='justify-center items-center px-2 py-1 text-center text-white font-semibold rounded-full mb-1 flex bg-transparent border-2'>
          Task Update
        </h2>
        
        <div className='overflow-auto h-[16vh] pb-5' id='tasklist'>
          {userData.map(function(employee) {
            return employee.tasks.map(function(task) {
              return (
                <div className='bg-gradient-to-r from-teal-500 to-blue-600 mb-2 py-2 px-2 flex justify-between rounded-full'>
                  <h1>{employee.firstName}</h1>
                  <h1>{task.title}</h1>
                  <h2>{task.completed ? "Completed" : task.failed ? "Failed" : "In Progress"}</h2>
                </div>
              );
            });
          })}
        </div>
      </div>
    </div>
  );
}

export default AllTask;
