import React from 'react'

const TaskListNumbers = ({data}) => {
  return (
    <div className="flex flex-wrap justify-center items-center gap-5 mt-10 px-6 w-full">
    <div className="w-full sm:w-[45%] bg-gradient-to-r from-teal-500 to-blue-600 rounded-2xl shadow-xl px-8 py-6 flex flex-col items-center text-center">
      <h2 className="text-4xl font-bold text-white">{data.taskNumber.newTask}</h2>
      <h3 className="text-lg font-medium text-white mt-2">New Task</h3>
    </div>

    <div className="w-full sm:w-[45%] bg-gradient-to-r from-teal-500 to-blue-600 rounded-2xl shadow-xl px-8 py-6 flex flex-col items-center text-center">
      <h2 className="text-4xl font-bold text-white">{data.taskNumber.active}</h2>
      <h3 className="text-lg font-medium text-white mt-2">Active Task</h3>
    </div>

    <div className="w-full sm:w-[45%] bg-gradient-to-r from-teal-500 to-blue-600 rounded-2xl shadow-xl px-8 py-6 flex flex-col items-center text-center">
      <h2 className="text-4xl font-bold text-white">{data.taskNumber.completed}</h2>
      <h3 className="text-lg font-medium text-white mt-2">Completed</h3>
    </div>

    <div className="w-full sm:w-[45%] bg-gradient-to-r from-teal-500 to-blue-600 rounded-2xl shadow-xl px-8 py-6 flex flex-col items-center text-center">
      <h2 className="text-4xl font-bold text-white">{data.taskNumber.failed}</h2>
      <h3 className="text-lg font-medium text-white mt-2">Failed Task</h3>
    </div>
  </div>
  )
}

export default TaskListNumbers
