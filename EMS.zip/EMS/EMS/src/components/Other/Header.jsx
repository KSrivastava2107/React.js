import React, { useState } from 'react';
import { setLocalStorage } from '../../utils/localStorage';

const Header = (props) => {
  
  //const [username,setUsername] = useState('')
  
  //if(!data){
  //  setUsername('Admin')
  //}else{
  //  setUsername(data.firstName)
  //}
  
  const logOutUser = () =>{
      localStorage.setItem('loggedInUser','')
      props.changeUser('')
      //window.location.reload()
  }

  return (
    <div className='flex items-end justify-between bg-gradient-to-r from-teal-500 to-blue-600 p-6 rounded-t-2xl w-full'>
      <h1 className='text-2xl font-medium text-white'>Hey! <br /> <span className='text-3xl'>Kritikey👋🏻</span></h1>
      <button onClick={logOutUser} className='bg-white text-lg font-medium text-teal-600 px-5 py-2 rounded-full shadow-md hover:bg-teal-600 hover:text-white  transition duration-300 ease-in-out'>
       Log Out
      </button>
    </div>
  );
}

export default Header;
