import React, { useState ,useContext} from 'react'
import { AuthContext } from '../../context/AuthProvider'

const CreateTask = () => {
  
  const [userData,setUserData] = useContext(AuthContext);

  const [taskTitle,setTaskTitle]=useState('')
  const [taskDescription,setTaskDescription]=useState('')
  const [taskDate,setTaskDate]=useState('')
  const [assignTo,setAssignTo]=useState('')
  const [category,setCategory]=useState('')

  const [newTask,setNewTask] = useState([])

  const submitHandler = (e) => {
    e.preventDefault()
    
    setNewTask({taskTitle,taskDescription,taskDate,category,active:false,newTask:true,failed:false,completed:false})
    const data= userData
    //JSON.parse(localStorage.getItem('employees'))
    
    userData.forEach(function(elem){
      if(assignTo==elem.firstName){
         elem.tasks.push(newTask)
         elem.taskNumber.newTask=elem.taskNumber.newTask+1
      }
    })
    //localStorage.setItem('employees',JSON.stringify(data))

    setUserData(data)
    console.log(data);
     

    setAssignTo('')
    setCategory('')
    //setNewTask('')
    setTaskDate('')
    setTaskDescription('')
    setTaskTitle('')
  }

  return (
    <div>
      <div>
        <form onSubmit={(e)=>{
          submitHandler(e)
        }} 
        id="tasklist" className="flex flex-col gap-6 h-[28.7vh] relative">
          <div className='flex'>
            <div>
              <div>
                <h3 className="text-lg font-semibold text-gray-400 mb-1 mt-2 mx-3">Task Title</h3>
                <input value={taskTitle} onChange={(e)=>{
                  setTaskTitle(e.target.value)
                }}
                  className="text-gray-800 bg-gray-100 border-2 border-gray-200 rounded-full text-lg px-5 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-300 outline-none placeholder-gray-500 w-[35vw] mx-1"
                  type="text"
                  placeholder="UI Design"
                />
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-400 mb-1 mx-3">Date</h3>
                <input value={taskDate} onChange={(e)=>{
                  setTaskDate(e.target.value)
                }}
                  className="text-gray-500 bg-gray-100 border-2 border-gray-200 rounded-full text-lg px-5 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-300 outline-none w-[35vw] mx-1"
                  type="date"
                />
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-400 mb-1 mx-3">Assign to</h3>
                <input value={assignTo} onChange={(e)=>{
                  setAssignTo(e.target.value)
                }}
                  className="text-gray-800 bg-gray-100 border-2 border-gray-200 rounded-full text-lg px-5 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-300 outline-none mx-1 placeholder-gray-500 w-[35vw]"
                  type="text"
                  placeholder="Employee Name"
                />
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-400 mb-1 mx-3">Category</h3>
                <input value={category} onChange={(e)=>{
                  setCategory(e.target.value)
                }}
                  className="text-gray-800 bg-gray-100 border-2 border-gray-200 rounded-full text-lg px-5 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-300 outline-none placeholder-gray-500 mx-1 w-[35vw]"
                  type="text"
                  placeholder="Design, Dev, Analyst"
                />
              </div>
            </div>

            <div className="flex justify-end w-[30vw] h-[30vh] ml-auto mr-10">
              <div className="w-[35vw]">
                <h3 className="text-lg font-semibold text-gray-400 mb-1 mx-3">Description</h3>
                <textarea value={taskDescription} onChange={(e)=>{
                  setTaskDescription(e.target.value)
                }}
                  className="bg-transparent border-2 border-gray-200 rounded- text-lg px-5 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-300 outline-none placeholder-gray-500 w-full text-gray-300"
                  placeholder="Task Description"
                />
              </div>
            </div>
          </div>

          <div className='flex items-center justify-center'>
            <button
              className="bg-teal-500 text-white rounded-full text-lg mt-11 px-3 py-3 justify-center align hover:bg-teal-600 transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none shadow-lg w-[10vw]"
            >
              Create Task
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default CreateTask

