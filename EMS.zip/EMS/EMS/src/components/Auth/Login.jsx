import React, { useState } from 'react'

const Login = ({handleLogin}) => {

const[email,setEmail]=useState('')
const[password,setPassword]=useState('')

const submitHandler=(e)=>{
    e.preventDefault()
    handleLogin(email,password)
    setEmail("")
    setPassword("")    
}

return (
  

<div className="flex h-screen w-screen items-center justify-center bg-gradient-to-r from-teal-500 to-blue-600">
  <div className="bg-white rounded-2xl shadow-2xl p-10 w-full max-w-md">
    <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">TASK MANAGER</h2>
    <form onSubmit={(e)=>{
       submitHandler(e) 
    }} className="flex flex-col gap-4">
      
      <input value={email} onChange={(e)=>{
         setEmail(e.target.value)
      }} className="required text-gray-800 bg-gray-100 border-2 border-gray-200 rounded-full text-lg px-5 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-300 outline-none placeholder-gray-500" type="email" placeholder="Enter Your Email"/>
      
      <input value={password} onChange={(e)=>{
         setPassword(e.target.value)
      }} className="required text-gray-800 bg-gray-100 border-2 border-gray-200 rounded-full text-lg px-5 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-300 outline-none placeholder-gray-500" type="password" placeholder="Password"/>
      
      <button className="bg-teal-500 text-white rounded-full text-lg px-5 py-3 mt-4 hover:bg-teal-600 transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none shadow-lg" type="submit">Login</button>
    </form>
    <div className="text-center mt-6">
      <a href="#" className="text-teal-500 hover:text-teal-600 text-sm">Forgot Password?</a>
    </div>
  </div>
</div>
  )
}

export default Login
