import React from 'react';
import Header from '../Other/Header';
import CreateTask from '../Other/CreateTask';
import AllTask from '../Other/AllTask';

const AdminDashboard = (props) => {
  return (
   
      <div className="rounded-2xl shadow-2xl p-7 w-[100vw] h-screen  bg-[#1C1C1C]">
        
        <h1 className='justify-center text-center text-lg font-semibold text-white mb-2 mx-0.5 bg-gradient-to-r from-teal-500 to-blue-600 rounded-full p-2'>TASK MANAGER</h1>


        <Header changeUser={props.changeUser} />
        <CreateTask/>
        <AllTask/>
      </div>
    
  );
};

export default AdminDashboard;
