import React from 'react'

const FailedTask = ({data}) => {
  return (
    <div className='flex-shrink-0 h-full p-5 w-[300px] border-2 rounded-xl'>
    <div className='flex justify-between items-center mb-3'>
      <h3 className='bg-gradient-to-r from-teal-500 to-blue-600 px-3 py-1 rounded text-white'>{data.category}</h3>
      <h4 className='text-white '>{data.date}</h4>
    </div>
    <h2 className='mt-5 text-xl font-semibold text-white'>{data.title}</h2>
    <p className='mt-2 text-white'>
      {data.description}
    </p>
    <div className='mt-2'>
        <button className='w-full'>Failed!</button>
    </div>
  </div>
  )
}

export default FailedTask
