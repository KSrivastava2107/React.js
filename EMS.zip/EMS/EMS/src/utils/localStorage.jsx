/*
const employees = [
    { 
      "id": 1,
      "email": "employee1@example.com",
      "password": "123",
      "tasks": [
        {
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false,
          "title": "Design Mockup",
          "description": "Create a mockup for the homepage.",
          "date": "2024-10-28",
          "category": "Design"
        },
        {
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false,
          "title": "Client Meeting",
          "description": "Discuss requirements with the client.",
          "date": "2024-10-15",
          "category": "Meetings"
        },
        {
          "active": false,
          "newTask": false,
          "completed": false,
          "failed": true,
          "title": "API Integration",
          "description": "Integrate payment API in the checkout module.",
          "date": "2024-10-20",
          "category": "Development"
        }
      ]
    },
    {
      "id": 2,
      "email": "employee2@example.com",
      "password": "123",
      "tasks": [
        {
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false,
          "title": "Update Documentation",
          "description": "Update user guide documentation.",
          "date": "2024-10-30",
          "category": "Documentation"
        },
        {
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false,
          "title": "Code Review",
          "description": "Review code for the latest feature.",
          "date": "2024-10-10",
          "category": "Code Review"
        }
      ]
    },
    {
      "id": 3,
      "email": "employee3@example.com",
      "password": "123",
      "tasks": [
        {
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false,
          "title": "Bug Fixing",
          "description": "Fix bugs reported in the mobile app.",
          "date": "2024-10-29",
          "category": "Development"
        },
        {
          "active": false,
          "newTask": false,
          "completed": false,
          "failed": true,
          "title": "Deploy Feature",
          "description": "Deploy new feature to production.",
          "date": "2024-10-18",
          "category": "Deployment"
        },
        {
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false,
          "title": "Team Meeting",
          "description": "Weekly sync-up with the team.",
          "date": "2024-10-05",
          "category": "Meetings"
        }
      ]
    },
    {
      "id": 4,
      "email": "employee4@example.com",
      "password": "123",
      "tasks": [
        {
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false,
          "title": "Design Review",
          "description": "Review UI designs with the client.",
          "date": "2024-10-22",
          "category": "Design"
        },
        {
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false,
          "title": "Database Backup",
          "description": "Perform database backup before update.",
          "date": "2024-10-28",
          "category": "Database"
        }
      ]
    },
    {
      "id": 5,
      "email": "employee5@example.com",
      "password": "123",
      "tasks": [
        {
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false,
          "title": "System Maintenance",
          "description": "Perform regular system maintenance.",
          "date": "2024-10-31",
          "category": "Maintenance"
        },
        {
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false,
          "title": "User Feedback Analysis",
          "description": "Analyze feedback for the latest release.",
          "date": "2024-10-12",
          "category": "Analysis"
        }
      ]
    }
  ];
  */

  const employees = [
    { 
      "id": 1,
      "email": "employee1@example.com",
      "password": "123",
      "firstName": "Amit",
      "taskNumber": {
        "active": 1,
        "newTask": 1,
        "completed": 1,
        "failed": 1
      },
      "tasks": [
        {
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false,
          "title": "Design Mockup",
          "description": "Create a mockup for the homepage.",
          "date": "2024-10-28",
          "category": "Design"
        },
        {
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false,
          "title": "Client Meeting",
          "description": "Discuss requirements with the client.",
          "date": "2024-10-15",
          "category": "Meetings"
        },
        {
          "active": false,
          "newTask": false,
          "completed": false,
          "failed": true,
          "title": "API Integration",
          "description": "Integrate payment API in the checkout module.",
          "date": "2024-10-20",
          "category": "Development"
        }
      ]
    },
    {
      "id": 2,
      "email": "employee2@example.com",
      "password": "123",
      "firstName": "Rajesh",
      "taskNumber": {
        "active": 1,
        "newTask": 1,
        "completed": 1,
        "failed": 0
      },
      "tasks": [
        {
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false,
          "title": "Update Documentation",
          "description": "Update user guide documentation.",
          "date": "2024-10-30",
          "category": "Documentation"
        },
        {
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false,
          "title": "Code Review",
          "description": "Review code for the latest feature.",
          "date": "2024-10-10",
          "category": "Code Review"
        }
      ]
    },
    {
      "id": 3,
      "email": "employee3@example.com",
      "password": "123",
      "firstName": "Sneha",
      "taskNumber": {
        "active": 1,
        "newTask": 1,
        "completed": 1,
        "failed": 1
      },
      "tasks": [
        {
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false,
          "title": "Bug Fixing",
          "description": "Fix bugs reported in the mobile app.",
          "date": "2024-10-29",
          "category": "Development"
        },
        {
          "active": false,
          "newTask": false,
          "completed": false,
          "failed": true,
          "title": "Deploy Feature",
          "description": "Deploy new feature to production.",
          "date": "2024-10-18",
          "category": "Deployment"
        },
        {
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false,
          "title": "Team Meeting",
          "description": "Weekly sync-up with the team.",
          "date": "2024-10-05",
          "category": "Meetings"
        }
      ]
    },
    {
      "id": 4,
      "email": "employee4@example.com",
      "password": "123",
      "firstName": "Priya",
      "taskNumber": {
        "active": 1,
        "newTask": 1,
        "completed": 1,
        "failed": 0
      },
      "tasks": [
        {
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false,
          "title": "Design Review",
          "description": "Review UI designs with the client.",
          "date": "2024-10-22",
          "category": "Design"
        },
        {
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false,
          "title": "Database Backup",
          "description": "Perform database backup before update.",
          "date": "2024-10-28",
          "category": "Database"
        }
      ]
    },
    {
      "id": 5,
      "email": "employee5@example.com",
      "password": "123",
      "firstName": "Vikram",
      "taskNumber": {
        "active": 1,
        "newTask": 1,
        "completed": 1,
        "failed": 0
      },
      "tasks": [
        {
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false,
          "title": "System Maintenance",
          "description": "Perform regular system maintenance.",
          "date": "2024-10-31",
          "category": "Maintenance"
        },
        {
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false,
          "title": "User Feedback Analysis",
          "description": "Analyze feedback for the latest release.",
          "date": "2024-10-12",
          "category": "Analysis"
        }
      ]
    }
];


  const admin = [
    {
      "id": 1,
      "email": "admin@example.com",
      "password": "123"
    }
  ];
  

  export const setLocalStorage = () =>{
     localStorage.setItem('employees',JSON.stringify(employees))
     localStorage.setItem('admin',JSON.stringify(admin))
  }

  
  export const getLocalStorage = () =>{
    const employees = JSON.parse(localStorage.getItem('employees'))
    const admin = JSON.parse(localStorage.getItem('admin'))
    return {employees,admin}
  }